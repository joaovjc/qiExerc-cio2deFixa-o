/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.QI.nota;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 *
 * @author joaovjc
 */
public class TesteTurma {
    public static void main(String[] args) {
        Turma turma = new Turma("matematica");
        turma.setAlunos(new Aluno("nome1","telefone","endereco","email","cpf","Matematica", 10.0, 10.0, 10.0,75));
        turma.setAlunos(new Aluno("nome2","telefone","endereco","email","cpf","Matematica", 9.0, 9.0, 9.0,75));
        turma.setAlunos(new Aluno("nome3","telefone","endereco","email","cpf","Matematica", 8.0, 8.0, 8.0,75));
        turma.setAlunos(new Aluno("nome4","telefone","endereco","email","cpf","Matematica", 7.0, 7.0, 7.0,75));
        turma.setAlunos(new Aluno("nome5","telefone","endereco","email","cpf","Matematica", 6.0, 6.0, 6.0,75));
        turma.setAlunos(new Aluno("nome6","telefone","endereco","email","cpf","Matematica", 5.0, 5.0, 5.0,75));
        turma.setAlunos(new Aluno("nome7","telefone","endereco","email","cpf","Matematica", 4.0, 4.0, 4.0,75));
        turma.setAlunos(new Aluno("nome8","telefone","endereco","email","cpf","Matematica", 3.0, 3.0, 3.0,75));
        turma.setAlunos(new Aluno("nome8","telefone","endereco","email","cpf","Matematica", 2.0, 2.0, 2.0,75));
        turma.setAlunos(new Aluno("nome8","telefone","endereco","email","cpf","Matematica", 1.0, 1.0, 1.0,75));       
        
        Collections.sort(turma.getAlunos(), (o1, o2) -> o1.compareTo(o2));
        turma.getAlunos().forEach(a -> System.out.println(a));
        System.out.println("================================================");
        
        turma.getAlunos().stream().filter(a-> a.calcularMedia() >= (turma.getAlunos().stream().mapToDouble(aluno -> aluno.calcularMedia()).sum())/(turma.getAlunos().stream().count())).forEach(System.out::println);
        
        
    }
    
    
}
