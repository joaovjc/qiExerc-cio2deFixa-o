/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.QI.nota;

import java.util.Random;

/**
 *
 * @author joaovjc
 */
public class Aluno extends DadosBasicos implements Comparable<Aluno>{
    
//    private List<Double> notas = new ArrayList<>();
    private double nota1;
    private double nota2;
    private double nota3;
    private double frequencia;
    private final int matricula;
    private String disciplina;
    private Random random = new Random();
    
    Aluno(String nome, String telefone, String endereco, String email, String cpf, String disci, double n1, double n2, double n3, double freq){
        super.setNome(nome);
        super.setTelefone(telefone);
        super.setEndereco(endereco);
        super.setEmail(email);
        super.setCpf(cpf);
        this.disciplina = disci;
        this.nota1= n1;
        this.nota2= n2;
        this.nota3= n3;
        this.frequencia = freq;
        this.matricula = random.nextInt(1000);
    }
    
//    public double calcularMedia(){
//        if(this.notas.stream().count() < 2) throw new IndexOutOfBoundsException(" O aluno cadastrado tem menos de 2 notas");
//        return (this.notas.stream().mapToDouble(c -> c).sum() / this.notas.stream().count());  
//    }

    
//    public void setNotas(Double nota) {
//        this.notas.add(nota);
//    }

    protected void setFrequencia(Double frequencia) {
        this.frequencia = frequencia;
    }
    
    protected double calcularMedia(){
        return ((nota1 + nota2 + nota3)/3);  
    }
    
    protected boolean aprovadoFrequencia(){
        return (frequencia >= 75);
    }
    
    public boolean situacaoAluno(){
        return (aprovadoFrequencia() && calcularMedia() >= 6);
    }
    
    @Override
    public int compareTo(Aluno aluno) {
        return  Double.compare(aluno.calcularMedia(), this.calcularMedia());
    }

    @Override
    public String toString() {
        return "O aluno: " + super.getNome() + " cursando a disciplina de " + this.disciplina + " tem uma média de " + this.calcularMedia() + " e um total de " + this.frequencia + "% de frequencia" ;
    }
    
    
}
