/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.QI.nota;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 *
 * @author joaovjc
 */
public class Turma {
    
    private List<Aluno> alunos = new ArrayList<>();
    private String disciplina;
    
    public Turma(String disciplina){
        this.disciplina = disciplina;
    }
    
    public List<Aluno> getAlunos() {
        return alunos;
    }

    public void setAlunos(Aluno aluno) {
        this.alunos.add(aluno);
    }

    public String getDisciplina() {
        return disciplina;
    }

    public void setDisciplina(String disciplina) {
        this.disciplina = disciplina;
    }
}
