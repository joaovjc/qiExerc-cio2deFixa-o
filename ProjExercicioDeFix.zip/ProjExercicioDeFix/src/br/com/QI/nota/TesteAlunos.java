/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.QI.nota;

/**
 *
 * @author joaovjc
 */
public class TesteAlunos {
    public static void main(String[] args) {
        
        Aluno aluno = new Aluno("nome","telefone","endereco","email","cpf","Matematica", 10.0, 10.0, 10.0, 75);
        
        
        
        System.out.println(aluno);
        System.out.println("Portanto ele esta " + ((aluno.situacaoAluno())? "Aprovado" : "reprovado"));
        
        
        
    }
}
