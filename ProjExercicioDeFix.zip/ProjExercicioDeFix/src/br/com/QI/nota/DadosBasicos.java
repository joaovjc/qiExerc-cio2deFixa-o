/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.QI.nota;

/**
 *
 * @author joaovjc
 */
public class DadosBasicos {
    
    private String nome; 
    private String telefone; 
    private String endereco; 
    private String Email;
    private String cpf;

    protected void setNome(String nome) {
        this.nome = nome;
    }

    protected void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    protected void setEndereco(String Endereço) {
        this.endereco = Endereço;
    }

    protected void setEmail(String Email) {
        this.Email = Email;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }
    
    
    public String getNome() {
        return nome;
    }

    public String getTelefone() {
        return telefone;
    }

    public String getEndereço() {
        return endereco;
    }

    public String getEmail() {
        return Email;
    }

    public String getCpf() {
        return cpf;
    }
    
    


}

