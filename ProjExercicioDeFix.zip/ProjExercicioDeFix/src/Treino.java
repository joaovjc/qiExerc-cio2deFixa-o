/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author joaovjc
 */
public class Treino {
    private String nome;
    private double marca;

    public Treino(double marca, String nome) {
        this.marca = marca;
        this.nome = nome;
    }
    
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getMarca() {
        return marca;
    }

    public void setMarca(double marca) {
        this.marca = marca;
    }

    @Override
    public String toString() {
        return "o nome do atleta é " + this.nome + " e a marca é " + this.marca; 
    }
    
    
    
}
